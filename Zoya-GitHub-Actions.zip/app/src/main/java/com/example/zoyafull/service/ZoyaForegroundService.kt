package com.example.zoyafull.service

import android.app.*
import android.content.Intent
import android.media.AudioRecord
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.zoyafull.audio.ZoyaWakeWordDetector
import com.example.zoyafull.live.GeminiLiveManager

class ZoyaForegroundService: Service() {
 private lateinit var detector: ZoyaWakeWordDetector
 private lateinit var live: GeminiLiveManager

 override fun onCreate() {
  super.onCreate()
  createChannel()
  startForeground(42, notification())
  live=GeminiLiveManager(applicationContext)
  detector=ZoyaWakeWordDetector()
  // Production implementation:
  // AudioRecord -> detector; detector callback -> live.connect().
  detector.start { live.connect() }
 }
 override fun onStartCommand(intent: Intent?, flags:Int, startId:Int)=START_STICKY
 override fun onDestroy() {
  detector.stop()
  live.close()
  super.onDestroy()
 }
 override fun onBind(intent:Intent?):IBinder?=null

 private fun createChannel() {
  getSystemService(NotificationManager::class.java).createNotificationChannel(
   NotificationChannel("zoya","Zoya Assistant",NotificationManager.IMPORTANCE_LOW))
 }
 private fun notification():Notification=
  NotificationCompat.Builder(this,"zoya")
   .setContentTitle("Zoya is active")
   .setContentText("Listening for “Zoya”")
   .setSmallIcon(android.R.drawable.ic_btn_speak_now)
   .setOngoing(true).build()
}
