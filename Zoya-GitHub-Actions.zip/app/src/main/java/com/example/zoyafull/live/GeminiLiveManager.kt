package com.example.zoyafull.live

import android.content.Context
import com.example.zoyafull.tools.ZoyaTools

class GeminiLiveManager(private val context:Context) {
 private val tools=ZoyaTools(context)

 suspend fun connect() {
  /*
   Current Google docs specify:
     model = "gemini-3.1-flash-live-preview"
     response modality = AUDIO
     custom function declarations can be supplied in Live config.

   Add the current @google/genai Android-compatible SDK dependency and
   use its Live session API here. The Live API requires the client to
   execute function calls and return tool responses.
  */
 }

 suspend fun sendPcm16(bytes:ByteArray) {
  // TODO: send realtime PCM16 audio to the Live session.
 }

 fun onAudioOutput(pcm16:ByteArray) {
  // TODO: AudioTrack playback.
 }

 suspend fun close() {
  // TODO: close Live session and release audio resources.
 }
}
