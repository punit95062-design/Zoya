package com.example.zoyafull.audio

/**
 * Local wake-word abstraction.
 * Replace the implementation with an on-device wake-word model.
 * Do not send continuous microphone audio to the cloud merely to detect "Zoya".
 */
class ZoyaWakeWordDetector {
 fun start(onWake:()->Unit) {
  // TODO: initialize AudioRecord and local wake-word model.
  // onWake() when "Zoya" is confidently detected.
 }
 fun stop() {}
}
