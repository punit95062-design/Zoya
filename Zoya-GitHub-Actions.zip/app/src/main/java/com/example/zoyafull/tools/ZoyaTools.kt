package com.example.zoyafull.tools

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

class ZoyaTools(private val context:Context) {

 fun openApp(packageName:String):Boolean {
  val launch=context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
  launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  context.startActivity(launch)
  return true
 }

 fun searchAndCallContact(contactName:String):Boolean {
  if(ContextCompat.checkSelfPermission(context,android.Manifest.permission.CALL_PHONE)
    !=PackageManager.PERMISSION_GRANTED) return false
  if(ContextCompat.checkSelfPermission(context,android.Manifest.permission.READ_CONTACTS)
    !=PackageManager.PERMISSION_GRANTED) return false

  val cursor=context.contentResolver.query(
   ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
   arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
   "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
   arrayOf("%$contactName%"),null) ?: return false

  cursor.use {
   if(!it.moveToFirst()) return false
   val number=it.getString(0)
   context.startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:$number"))
     .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
   return true
  }
 }

 fun sendWhatsAppMessage(contactName:String,message:String):Boolean {
  // Resolve the contact/number in production, then use the appropriate WhatsApp URI.
  val uri=Uri.parse("https://wa.me/?text=${Uri.encode(message)}")
  return try {
   context.startActivity(Intent(Intent.ACTION_VIEW,uri).apply {
    setPackage("com.whatsapp")
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
   })
   true
  } catch(_:Exception){false}
 }

 fun sendGmail(recipientEmail:String,subject:String,body:String):Boolean {
  return try {
   context.startActivity(Intent(Intent.ACTION_SENDTO).apply {
    data=Uri.parse("mailto:$recipientEmail")
    putExtra(Intent.EXTRA_SUBJECT,subject)
    putExtra(Intent.EXTRA_TEXT,body)
    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
   })
   true
  } catch(_:Exception){false}
 }
}
