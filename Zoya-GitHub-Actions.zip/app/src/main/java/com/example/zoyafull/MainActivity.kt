package com.example.zoyafull

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.zoyafull.service.ZoyaForegroundService

class MainActivity: ComponentActivity() {
 private val permissions=registerForActivityResult(
   ActivityResultContracts.RequestMultiplePermissions()){}
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  permissions.launch(arrayOf(
   Manifest.permission.RECORD_AUDIO,
   Manifest.permission.READ_CONTACTS,
   Manifest.permission.CALL_PHONE,
   Manifest.permission.POST_NOTIFICATIONS))
  setContent {
   MaterialTheme {
    Box(Modifier.fillMaxSize().background(Color(0xFF050509)), contentAlignment=Alignment.Center) {
     Column(horizontalAlignment=Alignment.CenterHorizontally) {
      Text("ZOYA", color=Color.White, style=MaterialTheme.typography.displayLarge)
      Text("Always ready. Never boring.", color=Color.LightGray)
      Spacer(Modifier.height(32.dp))
      Button(
       onClick={
        ContextCompat.startForegroundService(
         this@MainActivity, Intent(this@MainActivity,ZoyaForegroundService::class.java))
       },
       modifier=Modifier.size(170.dp), shape=CircleShape
      ){ Text("START ZOYA") }
     }
    }
   }
  }
 }
}
