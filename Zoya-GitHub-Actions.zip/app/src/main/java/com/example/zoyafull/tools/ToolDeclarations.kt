package com.example.zoyafull.tools

/**
 * These schemas are the conceptual function declarations to register
 * with the Gemini Live session:
 *
 * openApp(packageName: string)
 * searchAndCallContact(contactName: string)
 * sendWhatsAppMessage(contactName: string, message: string)
 * sendGmail(recipientEmail: string, subject: string, body: string)
 *
 * When the Live API emits a function call, execute it locally and send
 * the FunctionResponse back through the Live session.
 */
object ToolDeclarations
